

    std::cout << "Enter the number of elements in the second sequence: ";