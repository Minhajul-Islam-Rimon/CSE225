#include <iostream>
#include "unsortedtype.cpp"

using namespace std;

int main() {
    UnsortedType<int> list1;
    UnsortedType<int> list2;

    int m, n;
    cout << "Enter the number of elements in the first sequence: ";
    cin >> m;

    for (int i = 0; i < m; i++) {
        int value;
        cin >> value;
        list1.InsertItem(value);
    }

    cout << "Enter the number of elements in the second sequence: ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        int value;
        cin >> value;
        list2.InsertItem(value);
    }

    UnsortedType<int> combinedList;

    list1.ResetList();
    list2.ResetList();

    int item1, item2;

    list1.GetNextItem(item1);
    list2.GetNextItem(item2);

    while (list1.LengthIs() > 0 && list2.LengthIs() > 0) {
        if (item1 <= item2) {
            combinedList.InsertItem(item1);
            list1.GetNextItem(item1);
        } else {
            combinedList.InsertItem(item2);
            list2.GetNextItem(item2);
        }
    }

    while (list1.LengthIs() > 0) {
        list1.GetNextItem(item1);
        combinedList.InsertItem(item1);
    }

    while (list2.LengthIs() > 0) {
        list2.GetNextItem(item2);
        combinedList.InsertItem(item2);
    }

    combinedList.ResetList();
    int combinedItem;

    while (combinedList.LengthIs() > 0) {
        combinedList.GetNextItem(combinedItem);
        cout << combinedItem << " ";
    }

    cout << endl;

    return 0;
}
